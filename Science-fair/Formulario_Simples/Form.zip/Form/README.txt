## Linka o style.css no html se for usar o css de forma externa, por padrao vai tar o css embutido no html ##

matrizz :þ